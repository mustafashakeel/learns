<?php // Recipe 17: Image Display

require_once('../WDC.php');

ImageDisplay("pic.jpg", "", NULL);

// Try commenting out the above line and uncommenting one below

// ImageDisplay("pic.jpg", "gif",  NULL);
// ImageDisplay("pic.jpg", "png",  50);
// ImageDisplay("pic.jpg", "jpeg", 20);

?>
