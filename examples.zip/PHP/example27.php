<?php // Recipe 27: Embed YouTube Video

require_once('../WDC.php');

echo EmbedYouTubeVideo("VjnygQ02aW4", 370, 300, 1, 1, 0);

?>
