<?php // Recipe 26: Permanent Copyright

require_once('../WDC.php');

echo RollingCopyright("All rights reserved", 2003);

?>
