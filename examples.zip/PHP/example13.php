<?php // Recipe 13: Make Thumbnail

require_once('../WDC.php');

$image = imagecreatefromjpeg("test-source.jpg");
$thumb = MakeThumbnail($image, 100);
imagejpeg($thumb, "thumb.jpg");

$thumb2 = MakeThumbnail($image, 50);
imagejpeg($thumb2, "thumb2.jpg");

echo <<<_END
Here are the original and thumbnail images:<br /><img
src='test.jpg' align='left'>&nbsp;&nbsp;<img src='thumb.jpg'>
<br /><br />This thumbnail has maximum<br />dimensions of 100
pixels.<br /><br />Here's another with a maximum<br />50 pixels
width and height:<br /><br /><img src='thumb2.jpg'>
_END;

?>
