<?php // Recipe 6: Count Tail

require_once('../WDC.php');

for ($j = 0 ; $j < 101 ; ++$j)
   echo CountTail($j) . ", ";

?>
