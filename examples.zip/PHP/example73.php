<?php // Recipe 73: Fetch Wiki Page

require_once('../WDC.php');

echo '<html><head><meta http-equiv="Content-Type" ' .
     'content="text/html; charset=utf-8" /></head><body>';
echo '<font face="Verdana" size="2">';
echo FetchWikiPage('Climate Change');

?>
