<?php // Recipe 51: Users Online

require_once('../WDC.php');

echo "Users online: " . UsersOnline('users.txt', 300);

?>
